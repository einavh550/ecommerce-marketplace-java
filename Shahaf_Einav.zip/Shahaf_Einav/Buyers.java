package Shahaf_Einav;

import java.time.LocalDate;
public class Buyers {



    private String buyerName;
    private String buyerPassword;
    private String addressStreet;
    private int addressNumber;
    private String addressCity;
    private String addressCountry;
    private Item[] shoppingCart;
    private int logicalSizeItemsInCart; // Keeps track of the number of items added to cart
    private PurchaseHistory[] shoppingCartHistory; // array that contains the items, total price, and date of purchasing
    private int logicalSizeHistory;



    public Buyers(String buyerName, String buyerPassword, String addressStreet, int addressNumber, String addressCity, String addressCountry) {
        this.buyerName = buyerName;
        this.buyerPassword = buyerPassword;
        this.addressStreet = addressStreet;
        this.addressNumber = addressNumber;
        this.addressCity = addressCity;
        this.addressCountry = addressCountry;
        this.shoppingCart = new Item[2];
        this.logicalSizeItemsInCart = 0;
        this.shoppingCartHistory = new PurchaseHistory[2];
        this.logicalSizeHistory = 0;

    }

    public String getBuyerName() {
        return buyerName;
    }

    public String getBuyerPassword() {
        return buyerPassword;
    }

    public String getAddressStreet() {
        return addressStreet;
    }

    public int getAddressNumber() {
        return addressNumber;
    }

    public String getAddressCity() {
        return addressCity;
    }

    public String getAddressCountry() {
        return addressCountry;
    }

    public int getLogicalSizeItemsInCart() {
        return logicalSizeItemsInCart;
    }

    public String getItemName(int index) {
        if (index >= 0 && index < logicalSizeItemsInCart) {
            return shoppingCart[index].getName();
        }
        return null;
    }

    public double getItemPrice(int index) {
        if (index >= 0 && index < logicalSizeItemsInCart) {
            return shoppingCart[index].getPrice();
        }
        return -1;
    }

    public int getlogicalSizeHistory(){
        return logicalSizeHistory;
    }


    public void setBuyerName(String buyerName) {
        this.buyerName = buyerName;
    }

    public void setBuyerPassword(String buyerPassword) {
        this.buyerPassword = buyerPassword;
    }

    public void setAddressStreet(String addressStreet) {
        this.addressStreet = addressStreet;
    }

    public void setAddressNumber(int addressNumber) {
        this.addressNumber = addressNumber;
    }

    public void setAddressCity(String addressCity) {
        this.addressCity = addressCity;
    }

    public void setAddressCountry(String addressCountry) {
        this.addressCountry = addressCountry;
    }

    public void setLogicalSize(int logicalSize) {
        this.logicalSizeItemsInCart = logicalSize;
    }

    public void setItemName(int index, String itemName) {
        if (index >= 0 && index < logicalSizeItemsInCart) {
            shoppingCart[index].setName(itemName);
        }
    }

    public void setItemPrice(int index, double price) {
        if (index >= 0 && index < logicalSizeItemsInCart) {
            shoppingCart[index].setPrice(price);
        }
    }




    public void addItem(String itemName, double itemPrice) {
        if (logicalSizeItemsInCart >= shoppingCart.length) {
            // Resize the array if it's full
            resizeArray();
        }
        shoppingCart[logicalSizeItemsInCart] = new Item(itemName, itemPrice);
        logicalSizeItemsInCart++;
    }


    private void resizeArray() {
        Item[] newShoppingCart = new Item[shoppingCart.length * 2];
        for (int i = 0; i < shoppingCart.length; i++) {
            newShoppingCart[i] = shoppingCart[i];
        }
        shoppingCart = newShoppingCart;
    }

    public void printItems() {
        for (int i = 0; i < logicalSizeItemsInCart; i++) {
            Item item = shoppingCart[i];
            System.out.println("Item " + (i + 1) + ": " + item.getName() + ", Price: " + item.getPrice());
        }
    }



    public void todayDate(){
        LocalDate today = LocalDate.now();
        System.out.println("purchase date: " + today);
    }




    private void resetShoppingCart() {
        shoppingCart = new Item[2];
        logicalSizeItemsInCart = 0;
    }


    private void expandShoppingCartHistory() {
        PurchaseHistory[] newHistory = new PurchaseHistory[shoppingCartHistory.length * 2];
        for (int i = 0; i < shoppingCartHistory.length; i++) { //only for existing places with values
            newHistory[i] = shoppingCartHistory[i];
        }
        shoppingCartHistory = newHistory;
    }




    public Double checkOutShoppingCart() {
        double totalSum = 0;
        for (int i = 0; i < logicalSizeItemsInCart; i++) {
            totalSum += shoppingCart[i].getPrice();

        }
        return totalSum;
    }

    public Item[] itemsCopy() {
        Item[] itemsCopy = new Item[logicalSizeItemsInCart]; // logical place means amount of items in shopping cart
        for (int i = 0; i < logicalSizeItemsInCart; i++) {
            itemsCopy[i] = shoppingCart[i]; // puts in every place inside itemscopy the items inside shopping cart array
        }
        return itemsCopy;

    }


    public void addShoppingCartHistory(double payPrice,Item[] itemsCopy) {      // make sure to understand that needs to be sent with payprice
        if (logicalSizeHistory >= shoppingCartHistory.length) {
            expandShoppingCartHistory();
        }

        PurchaseHistory history = new PurchaseHistory(itemsCopy,payPrice, LocalDate.now());
        shoppingCartHistory[logicalSizeHistory] = history;
        resetShoppingCart();
        logicalSizeHistory++;
    }

    public void printShoppingCartHistory() {
        for (int i = 0; i < logicalSizeHistory; i++) {
            PurchaseHistory history = shoppingCartHistory[i];
            System.out.println("Purchase " + (i + 1) + ":");
            System.out.println("Date: " + history.getPurchaseDate());
            for (Item item : history.getItems()) {
                System.out.println(" - " + item.getName() + ": " + item.getPrice());
            }
            System.out.println(" ");
        }
    }






    public String toString() {
        return "Buyer Information:\n" +
                "------------------\n" +
                "Name: " + buyerName + "\n" +
                "Password: " + buyerPassword + "\n" +
                "Address:\n" +
                "  Street: " + addressStreet + "\n" +
                "  Street Number: " + addressNumber + "\n" +
                "  City: " + addressCity + "\n" +
                "  Country: " + addressCountry + "\n";
    }


}
