package Shahaf_Einav;

import java.time.LocalDate;

public class PurchaseHistory {
    private Item[] items;
    private double totalPrice;
    private LocalDate purchaseDate;

    public PurchaseHistory(Item[] items, double totalPrice, LocalDate purchaseDate) {
        this.items = items;
        this.totalPrice = totalPrice;
        this.purchaseDate = purchaseDate;
    }

    public Item[] getItems() {
        return items;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public LocalDate getPurchaseDate() {
        return purchaseDate;
    }
}
