package Shahaf_Einav;

public class Sellers {

    private String sellerName;
    private String sellerPassword;
    private Item[] sellerItems;
    private int logicalSize; // Keeps track of the number of items added

    public Sellers(String sellerName, String sellerPassword) {
        this.sellerName = sellerName;
        this.sellerPassword = sellerPassword;
        this.sellerItems = new Item[2]; // Initial size of the array ( length * 2)
        this.logicalSize = 0; // Initially, no items have been added yet
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getSellerPassword() {
        return sellerPassword;
    }

    public void setSellerPassword(String sellerPassword) {
        this.sellerPassword = sellerPassword;
    }

    public String getItemName(int index) {
        if (index >= 0 && index < logicalSize) {
            return sellerItems[index].getName();
        }
        return null;
    }

    public double getItemPrice(int index) {
        if (index >= 0 && index < logicalSize) {
            return sellerItems[index].getPrice();
        }
        return -1;
    }


    public int getLogicalSizeItemSellerArray() {
        return logicalSize;
    }



    public void addItem(String itemName, double itemPrice) {
        if (logicalSize >= sellerItems.length) {
            // Resize the array if it's full
            resizeArray();
        }
        sellerItems[logicalSize] = new Item(itemName, itemPrice);
        logicalSize++;
    }

    private void resizeArray() {
        Item[] newSellerItems = new Item[sellerItems.length * 2];
        for (int i = 0; i < sellerItems.length; i++) {
            newSellerItems[i] = sellerItems[i];
        }
        sellerItems = newSellerItems;
    }

    public void printItems() {
        for (int i = 0; i < logicalSize; i++) {
            Item item = sellerItems[i];
            System.out.println("Item " + (i + 1) + ": " + item.getName() + ", Price: " + item.getPrice());
        }
    }


    public String toString() {
        return "Seller name: " + sellerName + ", Seller password: " + sellerPassword;
    }
}
