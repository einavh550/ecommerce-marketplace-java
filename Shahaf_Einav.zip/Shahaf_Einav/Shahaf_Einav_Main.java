
// Einav Hillel, id: 211394754, Teacher: Keren
// Shahaf Shohat, id: 209234053, Teacher: Keren

package Shahaf_Einav;

import java.util.Scanner;

public class Shahaf_Einav_Main {

    public static void main (String[]args){
        ManagerClass manager = new ManagerClass();
        Scanner sc = new Scanner(System.in);
        menu(manager, sc);
    }

    public static void menu(ManagerClass manager, Scanner sc) {

        while (true) {
            System.out.println(" ");
            printMenu();
            System.out.println("Choose an option:");
            int answer = sc.nextInt();
            sc.nextLine();

            switch (answer) {
                case 0 -> {
                    System.out.println("Exiting the program.");
                    sc.close();
                    return;
                }
                case 1 -> addSellerInput(manager, sc);
                case 2 -> addBuyerInput(manager, sc);
                case 3 -> addItemToSeller(manager, sc);
                case 4 -> addItemToBuyerShoppingCart(manager, sc);
                case 5 -> CheckingOutBuyersCart(manager, sc);
                case 6 -> printBuyerData(manager, sc);
                case 7 -> printSellerData(manager, sc);
                default -> System.out.println("Invalid option. Please type again...");
            }
        }
    }

    public static void printMenu() {
        System.out.println("Hello and welcome to our digital store. ");
        System.out.println("To exit the program, Please type 0: ");
        System.out.println("To add a new seller to our platform, Please type 1: ");
        System.out.println("To add a new buyer to our platform, Please type 2: ");
        System.out.println("To add item to a seller's store, Please type 3: ");
        System.out.println("To add item to a buyer's shopping card, Please type 4: ");
        System.out.println("To check out a buyer's cart, Please type 5: ");
        System.out.println("To show all buyer's data, Please type 6: ");
        System.out.println("To show all seller's data, Please type 7: ");
    }



    public static void printArraySellers(Sellers[] array, int logicalSizeSeller) {
        for (int i = 0; i < logicalSizeSeller; i++) {
            System.out.println((i + 1) + ")" + array[i].getSellerName());
        }
    }

    public static void printArrayBuyers(Buyers[] array, int logicalSizeBuyer) {
        for (int i = 0; i < logicalSizeBuyer; i++) {
            System.out.println((i + 1) + ")" + array[i].getBuyerName());
        }
    }

    public static void printArrayBuyersData(Buyers[] array, int logicalSizeBuyer) {
        for (int i = 0; i < logicalSizeBuyer; i++) {
            System.out.println(" ");
            System.out.println("------------------");
            System.out.println((i + 1) + ")" + array[i].toString());
            if (array[i].getLogicalSizeItemsInCart() == 0){
                System.out.println("There are no items in: " + "'" + array[i].getBuyerName() + "'" + " Shopping cart.");
            }
            else {
                System.out.println("The buyer's current Shopping cart: ");
                array[i].printItems();
            }
            if (array[i].getlogicalSizeHistory() == 0) {
                System.out.println("'" + array[i].getBuyerName() + "'" + " Shopping cart history is empty, Please checkout your cart first. ");
            } else {
                System.out.println("Here is " + "'" + array[i].getBuyerName() + "'" + " Shopping cart history: ");
                array[i].printShoppingCartHistory();
            }
        }
    }
    public static void printArraySellersData(Sellers[] array, int logicalSizeSeller) {
        for (int i = 0; i < logicalSizeSeller; i++) {
            System.out.println("------------------");
            System.out.println((i + 1) + ")" + array[i].toString());
            if (array[i].getLogicalSizeItemSellerArray() == 0) {
                System.out.println("The Seller has no items available for sale at this moment.");
                System.out.println("------------------");
            } else {
                System.out.println("The Seller's items available for sale: ");
                array[i].printItems();
                System.out.println("------------------");
                System.out.println(" ");
            }
        }
    }







    public static void addSellerInput(ManagerClass manager, Scanner sc) {
        String sellerName = "";
        int attempts = 0;
        boolean nameTaken;
        System.out.println("Adding new seller to the platform.");

        do {
            if (attempts >= 5) {
                System.out.println("Maximum attempts reached. No seller added.");
                break; // Exit the do-while loop after 5 failed attempts
            }
            System.out.println("Please enter the name of the Seller (Alphabetic letters, numbers, and symbols only): ");
            sellerName = sc.nextLine();
            while (sellerName.equals("")) {
                System.out.println("Invalid name(Empty Input), please try again: ");
                sellerName = sc.nextLine();
            }

            nameTaken = manager.checkIfExistSellers(sellerName, manager.getSellers(), manager.getLogicalSizeSeller());
            if (nameTaken && attempts < 4) {
                System.out.println("The seller nickname already exists,you have " + (4 - attempts) + " tries left please choose another seller nickname.");
            }

            attempts++;
        } while (nameTaken);


        // If the user has not exceeded 5 attempts, proceed to get the password
        if (attempts < 5) {
            System.out.println("Please enter the password you want for this seller: ");
            String sellerPassword = sc.nextLine();

            manager.addSeller(sellerName, sellerPassword);
            System.out.println("You have been successfully added as a Seller. Your Seller number is: " + manager.getLogicalSizeSeller());
        }
    }

    public static void addBuyerInput(ManagerClass manager, Scanner sc) {
        String buyerName = "";
        int attempts = 0;
        boolean nameTaken;

        do {
            if (attempts >= 5) {
                System.out.println("Maximum attempts reached. No buyer added.");
                break; // Exit the do-while loop after 5 failed attempts
            }

            System.out.println("Please enter the name of the Buyer (Alphabetic letters, numbers, and symbols only): ");
            buyerName = sc.nextLine();
            while (buyerName.equals("")) {
                System.out.println("Invalid name, please try again: ");
                buyerName = sc.nextLine();
            }

            nameTaken = manager.checkIfExistBuyers(buyerName, manager.getBuyers(), manager.getLogicalSizeBuyer());
            if (nameTaken && attempts < 4) {
                System.out.println("The buyer nickname already exists,you have " + (4 - attempts) + " tries left please choose another buyer nickname.");
            }

            attempts++;
        } while (nameTaken);


        // If the user has not exceeded 5 attempts, proceed to get the password
        if (attempts < 5) {

            String buyerPassword;
            String addressStreet;
            int addressNumber;
            String addressCity;
            String addressCountry;

            System.out.println("Please enter the password: ");
            buyerPassword = sc.nextLine();
            System.out.println("Please enter the address street: ");
            addressStreet = sc.nextLine();
            System.out.println("Please enter the street number: ");
            addressNumber = sc.nextInt();
            sc.nextLine();
            System.out.println("Please enter the address city: ");
            addressCity = sc.nextLine();
            System.out.println("Please enter the address country: ");
            addressCountry = sc.nextLine();


            manager.addBuyer(buyerName, buyerPassword, addressStreet, addressNumber, addressCity,addressCountry);
            System.out.println("You have been successfully added as a buyer. Your buyer number is: " + (manager.getLogicalSizeBuyer()));
        }
    }
    public static void addItemToSeller(ManagerClass manager, Scanner sc){
        String itemName;
        double itemPrice;
        int indexSeller;

        System.out.println("Adding item to a seller's store.");

        if (manager.getLogicalSizeSeller() > 1) {
            printArraySellers(manager.getSellers(), manager.getLogicalSizeSeller());
            System.out.println("Please enter the index of the seller you would like to add item for: ");
            indexSeller = sc.nextInt();

            while (indexSeller < 1 || indexSeller > manager.getLogicalSizeSeller()) {
                System.out.println("The number of seller doesn't exist... ");
                printArraySellers(manager.getSellers(), manager.getLogicalSizeSeller());
                System.out.println("Please enter the number of the seller you would like to add item for: ");
                indexSeller = sc.nextInt();
            }
            sc.nextLine();
            System.out.println("The chosen Seller is: " + "'" + manager.getSellers()[indexSeller - 1].getSellerName() + "'");
        }

        else if (manager.getLogicalSizeSeller() == 1){
            System.out.println("The Seller is: "  + "'" + manager.getSellers()[0].getSellerName() + "'");
            indexSeller = 1;
        }

        else{
            System.out.println("There are no sellers in the platform... Please add seller first.");
            return;
        }


        System.out.println("Please enter the name of the product: ");
        itemName = sc.nextLine();
        System.out.println("Please enter the price of the product: ");
        itemPrice = sc.nextDouble();

        manager.getSellers()[indexSeller - 1].addItem(itemName, itemPrice);

        int lastItemIndex = manager.getSellers()[indexSeller - 1].getLogicalSizeItemSellerArray() - 1;
        System.out.println("The name of the product is: " + manager.getSellers()[indexSeller - 1].getItemName(lastItemIndex) + "\n" +
                "The price of the product is: " + manager.getSellers()[indexSeller - 1].getItemPrice(lastItemIndex));


    }

    public static void addItemToBuyerShoppingCart(ManagerClass manager, Scanner sc){
        int sellerNumber = 0;
        int buyerNumber = 0;
        int indexBuyer;
        int indexSeller;

        System.out.println("Adding item to a buyer's shopping cart.");

        if (manager.getLogicalSizeBuyer() > 1) {

            printArrayBuyers(manager.getBuyers(), manager.getLogicalSizeBuyer());
            System.out.println("Please enter the index of the buyer you would like to add item for: ");
            indexBuyer = sc.nextInt();

            while (indexBuyer < 1 || indexBuyer > manager.getLogicalSizeBuyer()) {
                System.out.println("The number of buyer doesn't exist, Please enter exist number from the list: ");
                printArrayBuyers(manager.getBuyers(), manager.getLogicalSizeBuyer());
                System.out.println("Please enter the index of the buyer you would like to add item for: ");
                indexBuyer = sc.nextInt();
            }
            buyerNumber = indexBuyer - 1;
            System.out.println("The chosen buyer is: " + "'" +  manager.getBuyers()[buyerNumber].getBuyerName() + "'");


        }
        else if (manager.getLogicalSizeBuyer() == 1){
            System.out.println("The buyer you would like to add item to is:" + "'" + manager.getBuyers()[buyerNumber].getBuyerName() + "'");
        }
        else{
            System.out.println("There are no buyers in the platform, Please add buyer first. ");
            return;
        }

        if (manager.getLogicalSizeSeller() > 1) {

            printArraySellers(manager.getSellers(), manager.getLogicalSizeSeller());
            System.out.println("Please enter the index of the seller you would like to buy from: ");
            indexSeller = sc.nextInt();

            while ((indexSeller < 1) || (indexSeller > manager.getLogicalSizeSeller())) {
                System.out.println("The index of seller doesn't exist, Please enter exist number from the list: ");
                printArraySellers(manager.getSellers(), manager.getLogicalSizeSeller());
                System.out.println("Please enter the index of the seller you would like to buy from: ");
                indexSeller = sc.nextInt();
            }
            sellerNumber = indexSeller - 1;
            System.out.println("The chosen seller to buy from is: "  + "'" + manager.getSellers()[sellerNumber].getSellerName() + "'");

        }
        else if (manager.getLogicalSizeSeller() == 1) {
            System.out.println("The (only one) Seller to buy from is: " + "'" + manager.getSellers()[sellerNumber].getSellerName() + "'");
        }
        else {
            System.out.println("There are no seller's in the platform, Please add seller first. ");
            return;
        }


        int amountOfItems = manager.getSellers()[sellerNumber].getLogicalSizeItemSellerArray();
        if (amountOfItems <= 0){
            System.out.println("There are no items this seller is currently selling...");
            System.out.println("Please add items to the seller's store first.");
            return;
        }
        manager.getSellers()[sellerNumber].printItems();
        System.out.println("Please choose item you would like to purchase from the seller: ");
        int itemIndexFromSeller = sc.nextInt();

        while (itemIndexFromSeller < 1 || itemIndexFromSeller > amountOfItems){
            System.out.println("The item number:" + itemIndexFromSeller + " doesn't exist, Please enter exist number from the list. ");
            manager.getSellers()[sellerNumber].printItems();
            System.out.println("Please choose item you would like to purchase from the seller: ");
            itemIndexFromSeller = sc.nextInt();
        }
        String itemNameFromSeller = manager.getSellers()[sellerNumber].getItemName(itemIndexFromSeller - 1);
        double itemPriceFromSeller = manager.getSellers()[sellerNumber].getItemPrice(itemIndexFromSeller - 1);

        manager.getBuyers()[buyerNumber].addItem(itemNameFromSeller, itemPriceFromSeller);
        System.out.println("The item has successfully added to  " + "'" + manager.getBuyers()[buyerNumber].getBuyerName() + "'" + "  buyer shopping cart.");
        System.out.println("Here is the updated Shopping cart: ");
        manager.getBuyers()[buyerNumber].printItems();
    }

    public static void CheckingOutBuyersCart(ManagerClass manager, Scanner sc){
        int index = 0;

        if (manager.getLogicalSizeBuyer() == 0) {
            System.out.println("There is no buyer in the store, Please add buyer first.");
        }

        else {
            System.out.println("Checking out a buyer's cart.");
            printArrayBuyers(manager.getBuyers(), manager.getLogicalSizeBuyer());
            System.out.println("Please enter the number of the buyer you would like to check out for: ");
            index = sc.nextInt();
            while (index < 1 || index > manager.getLogicalSizeBuyer()) {
                System.out.println("Wrong buyer number, Please enter a valid number from the list: ");
                printArrayBuyers(manager.getBuyers(), manager.getLogicalSizeBuyer());
                index = sc.nextInt();
            }
            if (manager.getBuyers()[index - 1].getLogicalSizeItemsInCart() <= 0) {
                System.out.println("There are no items in: "  + "'" + manager.getBuyers()[index - 1].getBuyerName() + "'" + " Shopping cart, Please add items before checking out.");
            }
            else{
                System.out.println("The chosen buyer to check out for is: "  + "'" + manager.getBuyers()[index - 1].getBuyerName() + "'");
                double payPrice  = manager.getBuyers()[index - 1].checkOutShoppingCart();
                Item[] itemsCopy = manager.getBuyers()[index - 1].itemsCopy();
                manager.getBuyers()[index - 1].todayDate(); //Printing the current date.
                System.out.println("The total price of the shopping cart is :" + "'" + payPrice + "'" + " " + "NIS");
                manager.getBuyers()[index - 1].addShoppingCartHistory(payPrice,itemsCopy);

            }
        }
    }

    public static void printBuyerData(ManagerClass manager, Scanner sc){
        if (manager.getLogicalSizeBuyer() == 0) {
            System.out.println("There are no buyers in the store to show data ... Please add buyer first.");
        }
        else {
            System.out.println("Showing all buyers in the platform.");
            System.out.println(" ");
            printArrayBuyersData(manager.getBuyers(), manager.getLogicalSizeBuyer());

        }
    }

    public static void printSellerData(ManagerClass manager, Scanner sc){
        if (manager.getLogicalSizeSeller() == 0) {
            System.out.println("There are no sellers in the store to show data, Please add seller first.");
        }
        else {
            System.out.println("Showing all seller's data.");
            printArraySellersData(manager.getSellers(), manager.getLogicalSizeSeller());
        }
    }

}









